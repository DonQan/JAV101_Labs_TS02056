package Lab7.poly.dao;

import java.util.List;
import Lab7.poly.entity.Employees;

public interface EmployeesDAO  {

    /** Truy vấn tất cả */
    List<Employees> findAll();

    /** Truy vấn theo mã */
    Employees findById(String id);

    /** Thêm mới */
    void create(Employees item);

    /** Cập nhật */
    void update(Employees item);

    /** Xóa theo mã */
    void deleteById(String id);

    /** Truy vấn theo DepartmentId (vì Employees có khóa ngoại) */
    List<Employees> findByDepartment(String departmentId);

    /** Kiểm tra nhân viên có tồn tại hay không */
    boolean existsById(String id);
    
    List<Employees> findByKeyword(String keyword); // THÊM
}
