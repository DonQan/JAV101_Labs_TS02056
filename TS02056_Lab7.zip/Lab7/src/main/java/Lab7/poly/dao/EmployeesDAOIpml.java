package Lab7.poly.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Lab7.poly.JDBC.Jdbc;
import Lab7.poly.entity.Employees;

public class EmployeesDAOIpml implements EmployeesDAO {
	@Override
	public List<Employees> findByKeyword(String keyword) {
	    String sql = "SELECT * FROM Employees WHERE Id LIKE ? OR Fullname LIKE ?";
	    List<Employees> list = new ArrayList<>();

	    try {
	        ResultSet rs = Jdbc.executeQuery(sql, "%" + keyword + "%", "%" + keyword + "%");
	        while (rs.next()) {
	            Employees e = new Employees();
	            e.setId(rs.getString("Id"));
	            e.setFullname(rs.getString("Fullname"));
	            e.setPassword(rs.getString("Password"));
	            e.setPhoto(rs.getString("Photo"));
	            e.setGender(rs.getBoolean("Gender"));
	            e.setBirthday(rs.getDate("Birthday"));
	            e.setSalary(rs.getDouble("Salary"));
	            e.setDepartmentId(rs.getString("DepartmentId"));
	            list.add(e);
	        }
	        rs.getStatement().getConnection().close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return list;
	}

    @Override
    public List<Employees> findAll() {
        String sql = "SELECT * FROM Employees";
        List<Employees> list = new ArrayList<>();

        try {
            ResultSet rs = Jdbc.executeQuery(sql);

            while (rs.next()) {
                Employees e = new Employees();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password"));
                e.setFullname(rs.getString("Fullname"));
                e.setPhoto(rs.getString("Photo"));
                e.setGender(rs.getBoolean("Gender")); 
                e.setBirthday(rs.getDate("Birthday"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                list.add(e);
            }
            return list;

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public Employees findById(String id) {
        String sql = "SELECT * FROM Employees WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);

            if (rs.next()) {
                Employees e = new Employees();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password"));
                e.setFullname(rs.getString("Fullname"));
                e.setPhoto(rs.getString("Photo"));
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getDate("Birthday"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                return e;
            }

            return null; // không tìm thấy

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void create(Employees e) {
        String sql = """
            INSERT INTO Employees (Id, Password, Fullname, Photo, Gender, Birthday, Salary, DepartmentId)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """;

        try {
            Jdbc.executeUpdate(sql,
                    e.getId(),
                    e.getPassword(),
                    e.getFullname(),
                    e.getPhoto(),
                    e.getGender(),
                    e.getBirthday(),
                    e.getSalary(),
                    e.getDepartmentId()
            );
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void update(Employees e) {
        String sql = """
            UPDATE Employees 
            SET Password=?, Fullname=?, Photo=?, Gender=?, Birthday=?, Salary=?, DepartmentId=?
            WHERE Id=?
        """;

        try {
            Jdbc.executeUpdate(sql,
                    e.getPassword(),
                    e.getFullname(),
                    e.getPhoto(),
                    e.getGender(),
                    e.getBirthday(),
                    e.getSalary(),
                    e.getDepartmentId(),
                    e.getId()
            );
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void deleteById(String id) {
        String sql = "DELETE FROM Employees WHERE Id=?";
        try {
            Jdbc.executeUpdate(sql, id);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    // ============= BONUS – nếu bạn thêm trong interface =============
    @Override
    public boolean existsById(String id) {
        return findById(id) != null;
    }

    @Override
    public List<Employees> findByDepartment(String departmentId) {
        String sql = "SELECT * FROM Employees WHERE DepartmentId=?";
        List<Employees> list = new ArrayList<>();

        try {
            ResultSet rs = Jdbc.executeQuery(sql, departmentId);

            while (rs.next()) {
                Employees e = new Employees();
                e.setId(rs.getString("Id"));
                e.setPassword(rs.getString("Password"));
                e.setFullname(rs.getString("Fullname"));
                e.setPhoto(rs.getString("Photo"));
                e.setGender(rs.getBoolean("Gender"));
                e.setBirthday(rs.getDate("Birthday"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                list.add(e);
            }
            return list;

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
