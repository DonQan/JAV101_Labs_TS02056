package Lab7.poly.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Lab7.poly.JDBC.Jdbc;
import Lab7.poly.entity.Department;

public class DepartmentDAOIpml implements DepartmentDAO {

    @Override
    public List<Department> findByKeyword(String keyword) {
        String sql = "SELECT * FROM Departments WHERE Id LIKE ? OR Name LIKE ?";
        List<Department> list = new ArrayList<>();

        try {
            ResultSet rs = Jdbc.executeQuery(
                sql,
                "%" + keyword + "%",
                "%" + keyword + "%"
            );

            while (rs.next()) {
                Department d = new Department();
                d.setId(rs.getString("Id"));
                d.setName(rs.getString("Name"));
                d.setDescription(rs.getString("Description"));
                list.add(d);
            }

            rs.getStatement().getConnection().close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public List<Department> findAll() {
        String sql = "SELECT * FROM Departments";
        List<Department> list = new ArrayList<>();

        try {
            ResultSet rs = Jdbc.executeQuery(sql);

            while (rs.next()) {
                Department d = new Department();
                d.setId(rs.getString("Id"));
                d.setName(rs.getString("Name"));
                d.setDescription(rs.getString("Description"));
                list.add(d);
            }

            rs.getStatement().getConnection().close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return list;
    }

    @Override
    public Department findById(String id) {
        String sql = "SELECT * FROM Departments WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);

            if (rs.next()) {
                Department d = new Department();
                d.setId(rs.getString("Id"));
                d.setName(rs.getString("Name"));
                d.setDescription(rs.getString("Description"));
                rs.getStatement().getConnection().close();
                return d;
            }

            rs.getStatement().getConnection().close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return null; // Không tìm thấy
    }

    @Override
    public void create(Department d) {
        String sql = "INSERT INTO Departments (Id, Name, Description) VALUES (?, ?, ?)";

        try {
            Jdbc.executeUpdate(sql,
                d.getId(),
                d.getName(),
                d.getDescription()
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void update(Department d) {
        String sql = "UPDATE Departments SET Name=?, Description=? WHERE Id=?";

        try {
            Jdbc.executeUpdate(sql,
                d.getName(),
                d.getDescription(),
                d.getId()
            );
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void deleteById(String id) {
        String sql = "DELETE FROM Departments WHERE Id=?";

        try {
            Jdbc.executeUpdate(sql, id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
