package Lab7.poly.servlet;

import Lab7.poly.dao.EmployeesDAO;
import Lab7.poly.dao.EmployeesDAOIpml;
import Lab7.poly.entity.Employees;
import org.apache.commons.beanutils.BeanUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@WebServlet({
        "/employees/index",
        "/employees/edit/*",
        "/employees/create",
        "/employees/update",
        "/employees/delete",
        "/employees/reset",
        "/employees/search"
})
public class EmployeesServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        EmployeesDAO dao = new EmployeesDAOIpml();
        Employees form = new Employees();
        List<Employees> list = new ArrayList<>();

        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (IllegalAccessException | InvocationTargetException e) {
            e.printStackTrace();
        }

        // Xử lý Birthday
        String birthday = req.getParameter("birthday");
        if (birthday != null && !birthday.trim().isEmpty()) {
            form.setBirthday(Date.valueOf(birthday));
        }

        String path = req.getServletPath();

        if (path.contains("edit")) {
            String id = req.getPathInfo();
            if (id != null && id.length() > 1) {
                id = id.substring(1);
                form = dao.findById(id);
            }

        } else if (path.contains("create")) {
            dao.create(form);
            form = new Employees();

        } else if (path.contains("update")) {
            dao.update(form);

        } else if (path.contains("delete")) {
            String id = req.getParameter("id");
            if (id != null) dao.deleteById(id);
            form = new Employees();

        } else if (path.contains("reset")) {
            form = new Employees();

        } else if (path.contains("search")) {
            String keyword = req.getParameter("keyword");
            list = dao.findByKeyword(keyword);
            req.setAttribute("item", new Employees());
            req.setAttribute("list", list);
            req.getRequestDispatcher("/Employees.jsp").forward(req, resp);
            return;
        }

        list = dao.findAll();

        req.setAttribute("item", form);
        req.setAttribute("list", list);
        req.getRequestDispatcher("/Employees.jsp").forward(req, resp);
    }
}
