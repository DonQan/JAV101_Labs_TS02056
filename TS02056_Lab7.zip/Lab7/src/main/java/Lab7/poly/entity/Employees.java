package Lab7.poly.entity;

import java.sql.Date;

public class Employees {
    String id; 
    String fullname;
    String password;
    String photo;
    Boolean gender;
    Date birthday;
    Double salary;
    String departmentId;

    // ====== Constructor RỖNG (BẮT BUỘC CHO DAO) ======
    public Employees() {
    }

    public Employees(String id, String fullname, String password, String photo, Boolean gender, Date birthday, Double salary, String departmentId) {
        this.id = id;
        this.fullname = fullname;
        this.password = password;
        this.photo = photo;
        this.gender = gender;
        this.birthday = birthday;
        this.salary = salary;
        this.departmentId = departmentId;
    }

    // ====== GETTER / SETTER ======
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getFullname() {
        return fullname;
    }
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoto() {
        return photo;
    }
    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Boolean getGender() {
        return gender;
    }
    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public Date getBirthday() {
        return birthday;
    }
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public Double getSalary() {
        return salary;
    }
    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public String getDepartmentId() {
        return departmentId;
    }
    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    @Override
    public String toString() {
        return "Employees [id=" + id + ", fullname=" + fullname + ", password=" + password 
                + ", photo=" + photo + ", gender=" + gender + ", birthday=" + birthday 
                + ", salary=" + salary + ", departmentId=" + departmentId + "]";
    }
}
