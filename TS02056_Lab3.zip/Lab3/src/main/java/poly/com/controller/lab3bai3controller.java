package poly.com.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet({"/lab3bai3","/lab3bai4"})
public class lab3bai3controller extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String chon = req.getRequestURI();

        if (chon.contains("/lab3bai3")) {

            Map<String,Object> map = new HashMap<>();
            map.put("name","samsung s25");
            map.put("price", 40000000);
            map.put("date", new Date());

            req.setAttribute("item", map);
            req.getRequestDispatcher("lab3bai3.jsp").forward(req, resp);

        } else {

            Map<String,Object> map = new HashMap<>();
            map.put("title","tieu de ban tin");
            map.put("content", "Noi dung ban tin thuong rat dai");

            req.setAttribute("item", map);
            req.getRequestDispatcher("lab3bai4.jsp").forward(req, resp);
        }
    }
}