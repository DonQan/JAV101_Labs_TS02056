﻿create database ABCNews
go
use ABCNews
go

-- 1. Bảng CATEGORIES (Loại tin)
CREATE TABLE CATEGORIES (
    Id VARCHAR(10) PRIMARY KEY, -- Mã loại tin
    Name NVARCHAR(50) NOT NULL  -- Tên loại tin
);
go
-- 2. Bảng USERS (Người dùng)
-- Giả định Role là BIT/BOOLEAN: 1 = Quản trị (TRUE), 0 = Phóng viên (FALSE)
CREATE TABLE USERS (
    Id VARCHAR(50) PRIMARY KEY,       -- Mã đăng nhập (Username)
    Password VARCHAR(50) NOT NULL,    -- Mật khẩu
    FullName NVARCHAR(100) NOT NULL,  -- Họ và tên
    Birthday DATE,                    -- Ngày sinh
    Gender BIT,                       -- Giới tính (1=Nam, 0=Nữ/Khác)
    Mobile VARCHAR(15),               -- Điện thoại
    Email VARCHAR(100) UNIQUE,        -- Email
    Role BIT NOT NULL                 -- Vai trò (1=Quản trị, 0=Phóng viên)
);
go
-- 3. Bảng NEWS (Bản tin)
-- Khóa ngoại trỏ đến CATEGORIES
CREATE TABLE NEWS (
    Id VARCHAR(10) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Content NVARCHAR(MAX) NOT NULL,
    Image VARCHAR(255),
    PostedDate DATETIME DEFAULT GETDATE(), -- Ngày đăng (Mặc định là ngày hiện tại)
    Author VARCHAR(50) NOT NULL,
    ViewCount INT DEFAULT 0,
    CategoryId VARCHAR(10) NOT NULL,
    Home BIT DEFAULT 0, -- Trang nhất (true=1/false=0)
    
    -- Khóa ngoại
    FOREIGN KEY (CategoryId) REFERENCES CATEGORIES(Id),
    FOREIGN KEY (Author) REFERENCES USERS(Id)
);
go
-- 4. Bảng NEWSLETTERS (Đăng ký nhận tin mới)
CREATE TABLE NEWSLETTERS (
    Email VARCHAR(100) PRIMARY KEY,   -- Email nhận tin
    Enabled BIT DEFAULT 1             -- Trạng thái (1=còn hiệu lực/0=hết hiệu lực)
);
go

INSERT INTO CATEGORIES (Id, Name) VALUES 
('SP', N'Thể Thao'),
('CN', N'Công Nghệ'),
('GT', N'Giải Trí');
go

INSERT INTO USERS (Id, Password, FullName, Birthday, Gender, Mobile, Email, Role) VALUES 
('admin', '123', N'Cá Sấu Gold', '1990-01-01', 1, '0987123456', 'admin@news.com', 1),
('thpbmt', '123', N'Phước Buôn Ma Thuột', '1995-05-15', 1, '0901543210', 'thpbmt@news.com', 1),
('user', '123', N'Đông Quân', '2000-11-20', 0, '0912345678', 'dongquan@news.com', 0);
go

INSERT INTO NEWS (Id, Title, Content, Image, Author, CategoryId, Home) VALUES 
('N001', N'World Cup 2026: Vòng loại căng thẳng', N'Nội dung tin tức thể thao...', 'wc2026.jpg', 'admin', 'SP', 1),
('N002', N'Chip AI thế hệ mới của Google', N'Nội dung tin tức công nghệ...', 'chip_v3.png', 'user', 'CN', 1),
('N003', N'Phim hành động mới nhất được công chiếu', N'Nội dung tin tức giải trí...', 'movie.jpg', 'thpbmt', 'GT', 0);
go

INSERT INTO NEWSLETTERS (Email, Enabled) VALUES 
('sub1@mail.com', 1),
('sub2@mail.com', 1),
('sub3@mail.com', 0);
go