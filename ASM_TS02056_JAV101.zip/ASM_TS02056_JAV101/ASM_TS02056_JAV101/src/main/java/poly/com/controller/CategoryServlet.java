package poly.com.controller;

import poly.com.dao.CategoryDAO;
import poly.com.model.Category;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// Đường dẫn servlet phải khớp với link trong menu (giả định)
@WebServlet(urlPatterns = {"/CategoryServlet"})
public class CategoryServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private CategoryDAO categoryDAO;

    @Override
    public void init() throws ServletException {
        super.init();
        categoryDAO = new CategoryDAO();
    }

    // =======================================================
    // I. Xử lý GET (Hiển thị danh sách, Xóa)
    // =======================================================
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if (action == null) {
            action = "list"; // Mặc định là hiển thị danh sách
        }

        try {
            switch (action) {
                case "delete":
                    deleteCategory(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "list":
                default:
                    listCategories(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    // Phương thức hiển thị danh sách loại tin
    private void listCategories(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Category> categoryList = categoryDAO.getAllCategories();
        request.setAttribute("categoryList", categoryList);
        
        // Nếu không có ID để sửa, đảm bảo newsToEdit là null
        if (request.getAttribute("categoryToEdit") == null) {
             request.setAttribute("categoryToEdit", null);
        }
        
        // Chuyển tiếp đến trang JSP quản lý loại tin
        request.getRequestDispatcher("QuanLyLoaiTin.jsp").forward(request, response);
    }
    
    // Phương thức hiển thị form sửa (cần lấy dữ liệu loại tin cũ)
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String id = request.getParameter("id");
        Category existingCategory = categoryDAO.getCategoryById(id);
        
        if (existingCategory != null) {
            // Đặt đối tượng loại tin vào request để form Thêm mới trở thành form Chỉnh sửa
            request.setAttribute("categoryToEdit", existingCategory);
        } else {
            request.getSession().setAttribute("message", "Không tìm thấy loại tin cần chỉnh sửa.");
        }
        
        // Gọi lại listCategories để tải lại trang với form sửa đã điền dữ liệu
        listCategories(request, response); 
    }

    // Phương thức xóa loại tin
    private void deleteCategory(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        String id = request.getParameter("id");
        boolean success = categoryDAO.deleteCategory(id);
        
        if (success) {
            request.getSession().setAttribute("message", "Đã xóa loại tin ID: " + id + " thành công.");
        } else {
            // Lỗi có thể do có khóa ngoại ràng buộc (tin tức đang dùng loại tin này)
            request.getSession().setAttribute("message", "Lỗi: Không thể xóa loại tin ID: " + id + ". Vui lòng kiểm tra các bản tin liên quan.");
        }
        response.sendRedirect("CategoryServlet"); // Quay lại trang danh sách sau khi xóa
    }

    // =======================================================
    // II. Xử lý POST (Thêm mới và Cập nhật)
    // =======================================================
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        String action = request.getParameter("action");
        
        // Lấy dữ liệu chung
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        
        try {
            if ("update".equals(action) && id != null && !id.isEmpty()) {
                updateCategory(request, response, id, name);
            } else {
                insertCategory(request, response, name); // ID sẽ được tạo tự động
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    // Phương thức thêm mới loại tin
    private void insertCategory(HttpServletRequest request, HttpServletResponse response, String name) 
            throws IOException {
        
        // Tạo ID tạm thời (Đây là logic business, bạn nên có một Service Layer để xử lý ID)
        String newId = "C" + new Date().getTime(); 
        
        Category newCategory = new Category(newId, name);
        
        boolean success = categoryDAO.addCategory(newCategory);
        
        if (success) {
            request.getSession().setAttribute("message", "Thêm loại tin mới thành công!");
        } else {
            request.getSession().setAttribute("message", "Lỗi: Thêm loại tin thất bại.");
        }
        
        response.sendRedirect("CategoryServlet"); 
    }
    
    // Phương thức cập nhật loại tin
    private void updateCategory(HttpServletRequest request, HttpServletResponse response, String id, String name) 
            throws IOException {
        
        Category updatedCategory = new Category(id, name);
        
        boolean success = categoryDAO.updateCategory(updatedCategory);
        
        if (success) {
            request.getSession().setAttribute("message", "Cập nhật loại tin ID: " + id + " thành công!");
        } else {
            request.getSession().setAttribute("message", "Lỗi: Cập nhật loại tin ID: " + id + " thất bại.");
        }
        
        response.sendRedirect("CategoryServlet");
    }
}