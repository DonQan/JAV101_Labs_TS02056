package poly.com.model;

import java.sql.Date;

public class User {
	private String id;
	private String password;
	private String fullname;
	private Date birthday;
	private boolean gender;
	private String mobile;
	private String email;
	private int role;
	
	public User() {
		super();
	}

	public User(String id, String password, String fullName, Date birthday, boolean gender, String mobile, String email,
			int role) {
		super();
		this.id = id;
		this.password = password;
		fullname = fullName;
		birthday = birthday;
		this.gender = gender;
		this.mobile = mobile;
		this.email = email;
		this.role = role;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullname;
	}

	public void setFullName(String fullName) {
		fullname = fullName;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		birthday = birthday;
	}

	public boolean isGender() {
		return gender;
	}

	public void setGender(boolean gender) {
		this.gender = gender;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int isRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}
	
	
}
