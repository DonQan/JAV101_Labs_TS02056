package poly.com.controller;

import poly.com.dao.NewsDAO;
import poly.com.model.News;
import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/index", "/home"}) // Ánh xạ tới /index hoặc /home
public class HomeServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private NewsDAO newsDAO;

    @Override
    public void init() throws ServletException {
        newsDAO = new NewsDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            // Lấy Tin nóng (isHome = true, giới hạn 1 bài)
            News hotNews = newsDAO.getHotNews(); // Giả định bạn có phương thức này
            
            // Lấy Tin tức mới nhất (Giới hạn 5-10 bài)
            List<News> latestNewsList = newsDAO.getLatestNews(10); // Giả định bạn có phương thức này
            
            request.setAttribute("hotNews", hotNews);
            request.setAttribute("latestNewsList", latestNewsList);
            
            // Chuyển tiếp đến giao diện
            request.getRequestDispatcher("index.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }
    }
}