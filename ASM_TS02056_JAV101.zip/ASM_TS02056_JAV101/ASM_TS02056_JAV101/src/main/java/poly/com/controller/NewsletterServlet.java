package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import poly.com.dao.NewsletterDAO;
import poly.com.model.Newsletter;

@WebServlet("/NewsletterServlet")
public class NewsletterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private NewsletterDAO dao;

    // Constructor để khởi tạo DAO
    public NewsletterServlet() {
        super();
        this.dao = new NewsletterDAO();
    }

    /**
     * Phương thức doGet xử lý hiển thị danh sách, tìm kiếm, xóa và cập nhật trạng thái.
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        String action = request.getParameter("action");
        String keyword = request.getParameter("keyword");
        
        try {
            if (action == null) {
                // Hiển thị mặc định (xem danh sách)
                fillTable(request, response);
                
            } else if (action.equalsIgnoreCase("delete")) {
                handleDelete(request, response);
                
            } else if (action.equalsIgnoreCase("toggle")) {
                handleToggleStatus(request, response);
                
            } else if (action.equalsIgnoreCase("search") && keyword != null) {
                handleSearch(request, response, keyword);
                
            } else {
                // Mặc định lại trang nếu không rõ action
                fillTable(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi thao tác dữ liệu: " + e.getMessage());
            fillTable(request, response); // Quay lại trang và hiển thị lỗi
        }
    }

    /**
     * Phương thức doPost xử lý Thêm mới (INSERT).
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Đảm bảo mã hóa UTF-8 cho dữ liệu đầu vào
        request.setCharacterEncoding("UTF-8");
        
        String email = request.getParameter("email");
        
        try {
            if (email != null && !email.trim().isEmpty()) {
                Newsletter existingEmail = dao.selectByID(email);
                
                if (existingEmail != null) {
                    request.setAttribute("error", "Email '" + email + "' đã tồn tại trong danh sách.");
                } else {
                    // Mặc định trạng thái là Enabled (1) khi thêm mới
                    Newsletter newEmail = new Newsletter(email, 1);
                    dao.insert(newEmail);
                    request.setAttribute("message", "Thêm email mới thành công!");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi thêm mới email: " + e.getMessage());
        }
        
        // Sau khi thêm, chuyển hướng về trang danh sách (sử dụng doGet)
        fillTable(request, response);
    }
    
    // =========================================================================
    // CÁC HÀM XỬ LÝ NỘI BỘ
    // =========================================================================

    /**
     * Tải toàn bộ danh sách và chuyển tiếp sang JSP.
     */
    private void fillTable(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        List<Newsletter> list = dao.selectAll();
        request.setAttribute("newsletterList", list);
        
        // Chuyển tiếp sang trang JSP để hiển thị
        request.getRequestDispatcher("/QuanLyNewsletter.jsp").forward(request, response);
    }
    
    /**
     * Xử lý tìm kiếm email theo từ khóa.
     */
    private void handleSearch(HttpServletRequest request, HttpServletResponse response, String keyword) 
            throws ServletException, IOException {
        
        // Do NewsletterDAO hiện tại không có hàm tìm kiếm theo từ khóa (LIKE),
        // Ta sẽ giả định thêm một hàm selectByKeyword(String keyword) vào DAO.
        // Tạm thời, tôi sẽ gọi selectAll và lọc (hoặc bạn có thể tự thêm hàm vào DAO).
        
        // *** GIẢ ĐỊNH: Đã thêm hàm searchByKeyword vào NewsletterDAO ***
        // List<Newsletter> list = dao.searchByKeyword(keyword);
        
        // Để code chạy được, ta sẽ lọc bằng tay trên toàn bộ danh sách:
        List<Newsletter> allList = dao.selectAll();
        List<Newsletter> filteredList = new ArrayList<>();
        
        if (keyword != null && !keyword.trim().isEmpty()) {
            String lowerCaseKeyword = keyword.trim().toLowerCase();
            for (Newsletter item : allList) {
                if (item.getEmail().toLowerCase().contains(lowerCaseKeyword)) {
                    filteredList.add(item);
                }
            }
        } else {
            // Nếu keyword rỗng, hiển thị tất cả
            filteredList = allList;
        }

        request.setAttribute("newsletterList", filteredList);
        request.setAttribute("searchKeyword", keyword); // Giữ lại keyword trên ô tìm kiếm
        request.setAttribute("message", "Đã tìm thấy " + filteredList.size() + " kết quả.");

        // Chuyển tiếp sang trang JSP để hiển thị kết quả
        request.getRequestDispatcher("/QuanLyNewsletter.jsp").forward(request, response);
    }


    /**
     * Xử lý xóa một email khỏi danh sách.
     */
    private void handleDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String emailToDelete = request.getParameter("email");
        
        if (emailToDelete != null) {
            dao.delete(emailToDelete);
            request.setAttribute("message", "Xóa email '" + emailToDelete + "' thành công.");
        }
        
        // Quay lại trang danh sách
        fillTable(request, response);
    }
    
    /**
     * Xử lý bật/tắt trạng thái (Enabled = 1 hoặc 0)
     */
    private void handleToggleStatus(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String statusStr = request.getParameter("status"); // Giá trị là 'true' hoặc 'false' từ công tắc
        
        if (email != null && statusStr != null) {
            Newsletter emailToUpdate = dao.selectByID(email);
            
            if (emailToUpdate != null) {
                // Chuyển 'true'/'false' thành 1/0
                int newStatus = Boolean.parseBoolean(statusStr) ? 1 : 0;
                emailToUpdate.setEnabled(newStatus);
                dao.update(emailToUpdate);
                
                String statusText = (newStatus == 1) ? "Kích hoạt" : "Vô hiệu hóa";
                request.setAttribute("message", statusText + " email '" + email + "' thành công.");
            }
        }
        
        // Quay lại trang danh sách
        fillTable(request, response);
    }

}