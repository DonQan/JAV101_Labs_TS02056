package poly.com.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import poly.com.model.User;

public class UserDAO extends Connectdao
{

	public User login(String id, String password) {
        String sql = "SELECT * FROM Users WHERE id = ? AND password = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User user = new User();
                user.setId(rs.getString("id"));
                user.setPassword(rs.getString("password"));
                user.setFullName(rs.getString("fullname"));
                return user; // trả về User nếu đăng nhập đúng
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null; // đăng nhập thất bại
    }
	
	
}

