package poly.com.dao;

import poly.com.model.Category;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

// CategoryDAO sử dụng các phương thức tĩnh từ ConnectDAO để thao tác DB
public class CategoryDAO {

    // Phương thức ánh xạ dữ liệu từ ResultSet sang đối tượng Category
    private Category mapResultSetToCategory(ResultSet rs) throws Exception {
        Category category = new Category();
        category.setId(rs.getString("Id"));
        category.setName(rs.getString("Name"));
        return category;
    }

    /**
     * Lấy tất cả các loại tin từ cơ sở dữ liệu.
     */
    public List<Category> getAllCategories() {
        List<Category> categoryList = new ArrayList<>();
        ResultSet rs = null;
        String sql = "SELECT * FROM CATEGORIES ORDER BY Name ASC"; 
        
        try {
            // Sử dụng phương thức tĩnh executeQuery của ConnectDAO
            rs = Connectdao.executeQuery(sql); 
            
            while (rs.next()) {
                categoryList.add(mapResultSetToCategory(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
        // Lưu ý: Việc đóng ResultSet phải được xử lý cẩn thận trong ConnectDAO 
        // hoặc phải được xử lý ngay sau khi gọi executeQuery.
        return categoryList;
    }
    
    /**
     * Tìm kiếm Loại tin theo Id.
     * @return đối tượng Category hoặc null nếu không tìm thấy.
     */
    public Category getCategoryById(String categoryId) {
        ResultSet rs = null;
        String sql = "SELECT * FROM CATEGORIES WHERE Id = ?";
        
        try {
            // Sử dụng phương thức tĩnh executeQuery của ConnectDAO
            rs = Connectdao.executeQuery(sql, categoryId);
            
            if (rs.next()) {
                return mapResultSetToCategory(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return null;
    }
    
    /**
     * Thêm một loại tin mới vào cơ sở dữ liệu.
     */
    public boolean addCategory(Category category) {
        String sql = "INSERT INTO CATEGORIES (Id, Name) VALUES (?, ?)";
        
        try {
            // Sử dụng phương thức tĩnh executeUpdate của ConnectDAO
            int rowsAffected = Connectdao.executeUpdate(sql, 
                category.getId(), 
                category.getName());

            return rowsAffected > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Cập nhật thông tin loại tin.
     */
    public boolean updateCategory(Category category) {
        String sql = "UPDATE CATEGORIES SET Name=? WHERE Id=?";
        
        try {
            // Sử dụng phương thức tĩnh executeUpdate của ConnectDAO
            int rowsAffected = Connectdao.executeUpdate(sql, 
                category.getName(), 
                category.getId());

            return rowsAffected > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Xóa loại tin theo Id.
     */
    public boolean deleteCategory(String categoryId) {
        String sql = "DELETE FROM CATEGORIES WHERE Id=?";
        
        try {
            // Sử dụng phương thức tĩnh executeUpdate của ConnectDAO
            int rowsAffected = Connectdao.executeUpdate(sql, categoryId);

            return rowsAffected > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}