package poly.com.model;

public class Category {
    private String id;   // Tương ứng với Id VARCHAR(10) PRIMARY KEY
    private String name; // Tương ứng với Name NVARCHAR(50) NOT NULL

    // Constructor mặc định
    public Category() {
    }

    // Constructor có tham số
    public Category(String id, String name) {
        this.id = id;
        this.name = name;
    }

    // --- Getters và Setters ---

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Tùy chọn: Phương thức toString để dễ dàng debug
    @Override
    public String toString() {
        return "Category{" +
               "id='" + id + '\'' +
               ", name='" + name + '\'' +
               '}';
    }
}