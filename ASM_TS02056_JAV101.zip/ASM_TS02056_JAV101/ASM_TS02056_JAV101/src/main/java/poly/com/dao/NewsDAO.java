package poly.com.dao;

import poly.com.model.News;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class NewsDAO {

    /**
     * Phương thức ánh xạ dữ liệu từ ResultSet sang đối tượng News.
     */
    private News mapResultSetToNews(ResultSet rs) throws Exception {
        News news = new News();
        news.setId(rs.getString("Id"));
        news.setTitle(rs.getString("Title"));
        news.setContent(rs.getString("Content"));
        news.setImage(rs.getString("Image"));
        news.setPostedDate(rs.getTimestamp("PostedDate"));
        news.setAuthor(rs.getString("Author"));
        news.setCategoryId(rs.getString("CategoryId"));
        news.setHome(rs.getBoolean("IsHome"));
        news.setViewCount(rs.getInt("ViewCount"));
        return news;
    }

    // =======================================================
    // 1. CREATE (Thêm mới)
    // =======================================================
    /**
     * Thêm một bản tin mới vào cơ sở dữ liệu.
     */
    public boolean addNews(News news) {
        String sql = "INSERT INTO NEWS (Id, Title, Content, Image, Author, CategoryId, IsHome) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try {
            int rowsAffected = Connectdao.executeUpdate(sql, 
                news.getId(), 
                news.getTitle(), 
                news.getContent(), 
                news.getImage(),
                news.getAuthor(),
                news.getCategoryId(),
                news.isHome());

            return rowsAffected > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // =======================================================
    // 2. READ (Lấy danh sách và chi tiết)
    // =======================================================
    /**
     * Lấy tất cả các bản tin từ cơ sở dữ liệu.
     */
    public List<News> getAllNews() {
        List<News> newsList = new ArrayList<>();
        ResultSet rs = null;
        String sql = "SELECT * FROM NEWS ORDER BY PostedDate DESC"; 
        
        try {
            rs = Connectdao.executeQuery(sql); 
            
            while (rs.next()) {
                newsList.add(mapResultSetToNews(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return newsList;
    }
    
    /**
     * Tìm kiếm bản tin theo Id.
     * @return đối tượng News hoặc null nếu không tìm thấy.
     */
    public News getNewsById(String newsId) {
        ResultSet rs = null;
        String sql = "SELECT * FROM NEWS WHERE Id = ?";
        
        try {
            rs = Connectdao.executeQuery(sql, newsId);
            
            if (rs.next()) {
                return mapResultSetToNews(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return null;
    }
    
    // =======================================================
    // 3. READ - Lấy tin cho trang chủ
    // =======================================================

    /**
     * Lấy một bài tin tức được đánh dấu là "Tin nóng" (IsHome = true) 
     * và mới nhất (theo PostedDate). (Sử dụng cú pháp SQL Server)
     * @return News object hoặc null nếu không có.
     */
    public News getHotNews() {
        // Tùy theo DB: SQL Server dùng TOP, MySQL dùng LIMIT
        String sql = "SELECT TOP 1 * FROM NEWS WHERE IsHome = 1 ORDER BY PostedDate DESC";
        ResultSet rs = null;
        
        try {
            rs = Connectdao.executeQuery(sql);
            if (rs.next()) {
                return mapResultSetToNews(rs);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Lấy danh sách các bài tin tức mới nhất. (Sử dụng cú pháp SQL Server)
     * @param limit Số lượng bài muốn lấy.
     * @return List<News> danh sách tin tức.
     */
    public List<News> getLatestNews(int limit) {
        List<News> newsList = new ArrayList<>();
        ResultSet rs = null;
        
        // Tùy theo DB: SQL Server dùng TOP, MySQL dùng LIMIT
        String sql;
        if (limit > 0) {
            sql = "SELECT TOP " + limit + " * FROM NEWS ORDER BY PostedDate DESC"; 
        } else {
            sql = "SELECT * FROM NEWS ORDER BY PostedDate DESC"; 
        }

        try {
            rs = Connectdao.executeQuery(sql);
            while (rs.next()) {
                newsList.add(mapResultSetToNews(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return newsList;
    }
    
    // =======================================================
    // 4. UPDATE (Cập nhật)
    // =======================================================
    /**
     * Cập nhật thông tin bản tin.
     * (Lưu ý: Bạn có thể cần thêm các trường khác như Image/PostedDate tùy thuộc vào yêu cầu)
     */
    public boolean updateNews(News news) {
        String sql = "UPDATE NEWS SET Title=?, Content=?, Image=?, CategoryId=?, IsHome=? WHERE Id=?";
        
        try {
            int rowsAffected = Connectdao.executeUpdate(sql, 
                news.getTitle(), 
                news.getContent(), 
                news.getImage(),
                news.getCategoryId(),
                news.isHome(),
                news.getId());

            return rowsAffected > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    // =======================================================
    // 5. DELETE (Xóa)
    // =======================================================
    /**
     * Xóa bản tin theo Id.
     */
    public boolean deleteNews(String newsId) {
        String sql = "DELETE FROM NEWS WHERE Id=?";
        
        try {
            int rowsAffected = Connectdao.executeUpdate(sql, newsId);

            return rowsAffected > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}