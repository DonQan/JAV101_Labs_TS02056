package poly.com.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import poly.com.model.Newsletter;

// Lớp này không cần kế thừa CrudDAO nếu ta không định nghĩa nó
public class NewsletterDAO {

    // Tạo một đối tượng Connectdao để đảm bảo kết nối được mở (nếu chưa mở)
    // Mặc dù các phương thức execute là static, việc khởi tạo này đảm bảo
    // constructor của Connectdao được gọi ít nhất một lần.
    public NewsletterDAO() {
        new Connectdao();
    }
    
    // Các câu lệnh SQL
    private final String INSERT_SQL = "INSERT INTO NEWSLETTERS (Email, Enabled) VALUES (?, ?)";
    private final String UPDATE_SQL = "UPDATE NEWSLETTERS SET Enabled=? WHERE Email=?";
    private final String DELETE_SQL = "DELETE FROM NEWSLETTERS WHERE Email=?";
    private final String SELECT_ALL_SQL = "SELECT * FROM NEWSLETTERS";
    private final String SELECT_BY_ID_SQL = "SELECT * FROM NEWSLETTERS WHERE Email=?";
    
    // =========================================================================
    // 1. CÁC PHƯƠNG THỨC CRUD
    // =========================================================================

    public void insert(Newsletter entity) {
        // Sử dụng phương thức tĩnh executeUpdate từ Connectdao
        Connectdao.executeUpdate(INSERT_SQL,
                entity.getEmail(),
                entity.getEnabled());
    }

    public void update(Newsletter entity) {
        // Sử dụng phương thức tĩnh executeUpdate từ Connectdao
        Connectdao.executeUpdate(UPDATE_SQL,
                entity.getEnabled(),
                entity.getEmail());
    }

    public void delete(String email) {
        // Sử dụng phương thức tĩnh executeUpdate từ Connectdao
        Connectdao.executeUpdate(DELETE_SQL, email);
    }

    public List<Newsletter> selectAll() {
        return selectBySQL(SELECT_ALL_SQL);
    }

    public Newsletter selectByID(String email) {
        List<Newsletter> list = selectBySQL(SELECT_BY_ID_SQL, email);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }
    
    // =========================================================================
    // 2. PHƯƠNG THỨC ÁNH XẠ DỮ LIỆU TỪ RESULTSET
    // =========================================================================

    /**
     * Phương thức nội bộ dùng để thực hiện truy vấn SELECT và ánh xạ ra danh sách List<Newsletter>.
     */
    protected List<Newsletter> selectBySQL(String sql, Object... args) {
        List<Newsletter> list = new ArrayList<>();
        
        // Sử dụng phương thức tĩnh executeQuery từ Connectdao
        // Lưu ý: Connectdao.executeQuery không đóng ResultSet và PreparedStatement,
        // nhưng chúng ta sẽ xử lý kết quả ở đây.
        try (ResultSet rs = Connectdao.executeQuery(sql, args)) {
            
            // Xử lý ResultSet trả về
            while (rs != null && rs.next()) {
                Newsletter entity = new Newsletter();
                entity.setEmail(rs.getString("Email"));
                entity.setEnabled(rs.getInt("Enabled")); 
                
                list.add(entity);
            }
        } catch (Exception e) {
            // In lỗi và ném lại lỗi để báo hiệu thất bại
            e.printStackTrace();
            throw new RuntimeException("Lỗi truy vấn CSDL trong NewsletterDAO: " + e.getMessage(), e);
        }
        return list;
    }
}