package poly.com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// Thư viện JavaMail API
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import poly.com.dao.NewsletterDAO;
import poly.com.model.Newsletter;

@WebServlet("/MailServlet")
public class MailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private NewsletterDAO dao = new NewsletterDAO();

    // THÔNG TIN EMAIL GỬI
    private final String SENDER_EMAIL = "quannvdts02056@gmail.com";
    private final String SENDER_PASSWORD = "wkqq qqqq whdm cgpm"; // Thay bằng App Password
    private final String SMTP_HOST = "smtp.gmail.com";
    private final String SMTP_PORT = "587";
    
    // NỘI DUNG EMAIL MẪU
    private final String SUBJECT = "Bản tin mới nhất từ ABC News!";
    private final String CONTENT = "Xin chào! Đây là bản tin mới của chúng tôi. Hãy truy cập trang web để đọc chi tiết.\n\nTrân trọng,\nABC News Team";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 1. Lấy danh sách email cần gửi (Chỉ lấy những email Enabled = 1)
        List<Newsletter> allList = dao.selectAll();
        int successCount = 0;
        
        for (Newsletter recipient : allList) {
            // Chỉ gửi nếu trạng thái là Enabled (1)
            if (recipient.getEnabled() == 1) {
                try {
                    sendEmail(recipient.getEmail(), SUBJECT, CONTENT);
                    successCount++;
                } catch (Exception e) {
                    System.err.println("Lỗi gửi mail tới " + recipient.getEmail() + ": " + e.getMessage());
                    // Tiếp tục vòng lặp để gửi các email khác
                }
            }
        }

        // 2. Chuyển hướng lại trang quản lý và hiển thị kết quả
        String message = "Đã hoàn tất việc gửi Newsletter. Gửi thành công tới " + successCount + " địa chỉ.";
        request.setAttribute("message", message);
        
        // Cần tải lại danh sách để đảm bảo thông báo hiển thị đúng
        request.setAttribute("newsletterList", allList); 
        request.getRequestDispatcher("/QuanLyNewsletter.jsp").forward(request, response);
    }
    
    /**
     * Hàm gửi email sử dụng JavaMail API
     */
    private void sendEmail(String recipientEmail, String subject, String content) throws Exception {
        
        // 1. Thiết lập các thuộc tính kết nối SMTP
    	Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true"); // BẬT STARTTLS
        props.put("mail.smtp.host", SMTP_HOST); // smtp.gmail.com
        props.put("mail.smtp.port", SMTP_PORT); // 587

        // >>> THÊM CẤU HÌNH QUAN TRỌNG NÀY (Nếu bạn dùng Java cũ hơn 8 hoặc môi trường server kén chọn)
        props.put("mail.smtp.ssl.protocols", "TLSv1.2"); 
        
        // TÙY CHỌN: Nếu 587 vẫn lỗi, thử dùng cổng 465 (SSL mặc định) và thêm cấu hình Socket Factory:
        /*
        // Nếu bạn đổi PORT = 465, dùng cấu hình này:
        props.put("mail.smtp.port", "465");
        props.put("mail.smtp.ssl.enable", "true"); 
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory"); 
        */;

        // 2. Tạo Session với thông tin xác thực
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
            }
        });

        // 3. Tạo thông điệp email
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(SENDER_EMAIL));
        message.setRecipients(
                Message.RecipientType.TO, 
                InternetAddress.parse(recipientEmail)
        );
        message.setSubject(subject);
        message.setText(content); // Gửi nội dung dạng văn bản thuần
        
        // *Nếu bạn muốn gửi HTML, dùng message.setContent(htmlContent, "text/html");

        // 4. Gửi thông điệp
        Transport.send(message);
    }
}