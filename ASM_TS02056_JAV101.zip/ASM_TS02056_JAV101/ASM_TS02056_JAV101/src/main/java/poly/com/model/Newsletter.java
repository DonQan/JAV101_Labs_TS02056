package poly.com.model;

public class Newsletter {
	private String email;
	private int enabled;
	public Newsletter(String email, int enabled) {
		super();
		this.email = email;
		this.enabled = enabled;
	}
	public Newsletter() {
		
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	
	
}
