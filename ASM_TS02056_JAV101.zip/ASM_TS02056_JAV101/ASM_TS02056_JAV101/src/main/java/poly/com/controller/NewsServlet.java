package poly.com.controller;

import poly.com.dao.NewsDAO;
import poly.com.dao.CategoryDAO; // Cần thiết để lấy danh sách Category
import poly.com.model.News;
import poly.com.model.Category; // Import Category model
import poly.com.model.User; // Giả định User model để lấy Author ID

import java.io.IOException;
import java.util.Date;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part; // Cho upload file

// Đường dẫn servlet phải khớp với action trong form và các liên kết thao tác (VD: quanlitintuc)
@WebServlet(urlPatterns = {"/quanlitintuc"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
                 maxFileSize = 1024 * 1024 * 10,      // 10MB
                 maxRequestSize = 1024 * 1024 * 50)   // 50MB
public class NewsServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private NewsDAO newsDAO;
    private CategoryDAO categoryDAO; // Giả định CategoryDAO tồn tại

    @Override
    public void init() throws ServletException {
        super.init();
        newsDAO = new NewsDAO();
        categoryDAO = new CategoryDAO(); // Khởi tạo CategoryDAO
    }

    // =======================================================
    // I. Xử lý GET (Hiển thị danh sách, Chỉnh sửa, Xóa)
    // =======================================================
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if (action == null) {
            action = "list"; // Mặc định là hiển thị danh sách
        }

        try {
            switch (action) {
                case "edit":
                    showEditForm(request, response);
                    break;
                case "delete":
                    deleteNews(request, response);
                    break;
                case "list":
                default:
                    listNews(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    // Phương thức hiển thị danh sách tin tức
    private void listNews(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Lấy danh sách tin tức
        List<News> newsList = newsDAO.getAllNews();
        request.setAttribute("newsList", newsList);
        
        // 2. Lấy danh sách loại tin (cho form Thêm/Sửa)
        List<Category> categoryList = categoryDAO.getAllCategories();
        request.setAttribute("categoryList", categoryList);
        
        // 3. Chuyển tiếp đến trang JSP
        request.getRequestDispatcher("QuanLyTinTuc.jsp").forward(request, response);
    }
    
    // Phương thức hiển thị form sửa (cần lấy dữ liệu tin tức cũ)
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String id = request.getParameter("id");
        News existingNews = newsDAO.getNewsById(id);
        
        if (existingNews != null) {
            // Lấy danh sách loại tin
            List<Category> categoryList = categoryDAO.getAllCategories();
            request.setAttribute("categoryList", categoryList);
            
            // Đặt đối tượng tin tức vào request để form có thể điền dữ liệu
            request.setAttribute("newsToEdit", existingNews);
            
            // Đặt lại danh sách tin tức để trang vẫn hiển thị bảng
            List<News> newsList = newsDAO.getAllNews();
            request.setAttribute("newsList", newsList);
            
            request.getRequestDispatcher("QuanLyTinTuc.jsp").forward(request, response);
        } else {
            request.getSession().setAttribute("message", "Không tìm thấy bản tin cần chỉnh sửa.");
            response.sendRedirect("quanlitintuc"); // Quay lại trang danh sách
        }
    }

    // Phương thức xóa tin tức
    private void deleteNews(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        String id = request.getParameter("id");
        boolean success = newsDAO.deleteNews(id);
        
        if (success) {
            request.getSession().setAttribute("message", "Đã xóa bản tin ID: " + id + " thành công.");
        } else {
            request.getSession().setAttribute("message", "Lỗi: Không thể xóa bản tin ID: " + id + ".");
        }
        response.sendRedirect("quanlitintuc"); // Quay lại trang danh sách sau khi xóa
    }

    // =======================================================
    // II. Xử lý POST (Thêm mới và Cập nhật)
    // =======================================================
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Đặt encoding để đọc tiếng Việt
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        String action = request.getParameter("action");
        if (action == null) {
            action = "insert"; // Mặc định từ form Thêm mới
        }
        
        try {
            switch (action) {
                case "update":
                    updateNews(request, response);
                    break;
                case "insert":
                default:
                    insertNews(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

    // Phương thức thêm mới tin tức
    private void insertNews(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        
        // 1. Lấy dữ liệu từ form
        String id = "N" + new Date().getTime(); 
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String categoryId = request.getParameter("categoryID");
        boolean isHome = "true".equals(request.getParameter("isHome")); 
        
        // 2. Xử lý Upload file ảnh
        String imagePath = handleImageUpload(request);
        
        // 3. Lấy ID tác giả từ Session
        String authorId = "ADMIN001"; 
        
        // 4. Tạo đối tượng News
        News newNews = new News();
        newNews.setId(id);
        newNews.setTitle(title);
        newNews.setContent(content);
        newNews.setImage(imagePath);
        newNews.setAuthor(authorId);
        newNews.setCategoryId(categoryId);
        newNews.setHome(isHome);
        
        // 5. Thêm vào DB
        boolean success = newsDAO.addNews(newNews);
        
        if (success) {
            // Đặt thông báo vào Session (để index.jsp có thể hiển thị sau redirect)
            request.getSession().setAttribute("message", "Thêm bản tin mới thành công!");
            
            // THAY ĐỔI: Chuyển hướng sang trang chủ (index.jsp)
            response.sendRedirect("index.jsp"); 
        } else {
            // Giữ nguyên logic quay lại trang quản lý nếu thất bại
            request.getSession().setAttribute("message", "Lỗi: Thêm bản tin thất bại.");
            response.sendRedirect("quanlitintuc"); 
        }
    }
    
    // Phương thức cập nhật tin tức (chưa hoàn chỉnh, cần Id trong form)
    private void updateNews(HttpServletRequest request, HttpServletResponse response) 
            throws IOException, ServletException {
        
        // Giả định bạn đã thêm trường hidden ID vào form sửa
        String id = request.getParameter("newsId"); 
        
        // Tương tự như insert, lấy các trường còn lại và gọi newsDAO.updateNews(news)
        
        request.getSession().setAttribute("message", "Chức năng cập nhật chưa được triển khai hoàn chỉnh!");
        response.sendRedirect("quanlitintuc");
    }
    
    // Phương thức xử lý upload file ảnh (Cần thư mục "images" trong WebContent)
    private String handleImageUpload(HttpServletRequest request) throws IOException, ServletException {
        try {
            Part filePart = request.getPart("image");
            if (filePart == null || filePart.getSize() == 0) {
                return null; // Không có file ảnh được upload
            }
            
            String fileName = extractFileName(filePart);
            String savePath = getServletContext().getRealPath("/") + "images"; // Đường dẫn lưu trữ
            
            // Tạo thư mục nếu chưa tồn tại
            java.io.File fileSaveDir = new java.io.File(savePath);
            if (!fileSaveDir.exists()) {
                fileSaveDir.mkdir();
            }
            
            // Ghi file vào thư mục
            String filePath = savePath + java.io.File.separator + fileName;
            filePart.write(filePath);
            
            // Trả về đường dẫn tương đối (chỉ tên file) để lưu vào DB
            return fileName; 
            
        } catch (Exception e) {
            e.printStackTrace();
            return null; // Xử lý lỗi upload
        }
    }
    
    // Phương thức trích xuất tên file từ Part
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return new Date().getTime() + ".jpg"; // Tên file mặc định nếu không tìm thấy
    }
}